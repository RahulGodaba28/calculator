const display = document.getElementById("display");
const buttons = document.querySelectorAll(".btn");

let currentInput = "";

function updateDisplay() {
  display.textContent = currentInput || "0";
  display.classList.add("glow");
  setTimeout(() => display.classList.remove("glow"), 150);
}

buttons.forEach(button => {
  button.addEventListener("click", () => {
    const value = button.textContent;

    if (button.classList.contains("clear")) {
      currentInput = "";
    } else if (button.classList.contains("delete")) {
      currentInput = currentInput.slice(0, -1);
    } else if (button.classList.contains("equal")) {
      try {
        currentInput = eval(currentInput).toString();
      } catch {
        currentInput = "Error";
      }
    } else {
      currentInput += value;
    }

    updateDisplay();
  });
});
